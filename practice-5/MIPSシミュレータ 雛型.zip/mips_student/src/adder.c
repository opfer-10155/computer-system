#include <stdio.h>
#include <mips.h>

void full_adder(Signal in1, Signal in2, Signal carry_in, Signal *out1, Signal *carry_out)
{
    /* Exercise 5-2 */
}

void rca(Word in1, Word in2, Signal carry_in, Word *out1, Signal *carry_out)
{
    /* Excercise 5-3 */
}

void test_full_adder()
{
    /* Exercise 5-2 */
}

void test_rca(int val1, int val2)
{
    /* Excercise 5-3 */
}

