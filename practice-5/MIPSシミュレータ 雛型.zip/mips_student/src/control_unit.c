#include <mips.h>

void control_unit(Signal opcode[6], Signal *register_dst, Signal *register_write, Signal *aluop1)
{
    /* Exercise 8-1 */
}

void alu_control_unit(Signal *funct, Signal aluop1, Signal *ops)
{
    /* Exercise 8-1 */
}
